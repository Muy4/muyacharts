http://manbow.nothing.sh/event/event.cgi?action=More_def&num=51&event=129
a_liar_template����